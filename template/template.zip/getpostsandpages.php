<?php 
if($api_response->haveAds!="False") : 
		$ads=$api_response->ads;
endif;
if($api_response->havePages!="False") : 
	$pages=$api_response->pages;
endif;
?>